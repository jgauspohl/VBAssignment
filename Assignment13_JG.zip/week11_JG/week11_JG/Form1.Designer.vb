﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtTripLength = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtAirfare = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtLodging = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtFood = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radManagement = New System.Windows.Forms.RadioButton()
        Me.radNonManagement = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.lblCompanyReimbursed = New System.Windows.Forms.Label()
        Me.lblEmployeeDue = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(117, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(134, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Trip length (days):"
        '
        'txtTripLength
        '
        Me.txtTripLength.Location = New System.Drawing.Point(277, 42)
        Me.txtTripLength.Name = "txtTripLength"
        Me.txtTripLength.Size = New System.Drawing.Size(124, 26)
        Me.txtTripLength.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(117, 107)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(83, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Airfare ($):"
        '
        'txtAirfare
        '
        Me.txtAirfare.Location = New System.Drawing.Point(277, 107)
        Me.txtAirfare.Name = "txtAirfare"
        Me.txtAirfare.Size = New System.Drawing.Size(124, 26)
        Me.txtAirfare.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(117, 169)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(132, 20)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Lodging (Total $):"
        '
        'txtLodging
        '
        Me.txtLodging.Location = New System.Drawing.Point(277, 169)
        Me.txtLodging.Name = "txtLodging"
        Me.txtLodging.Size = New System.Drawing.Size(124, 26)
        Me.txtLodging.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(117, 231)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(120, 20)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Dining (Total $):"
        '
        'txtFood
        '
        Me.txtFood.Location = New System.Drawing.Point(277, 231)
        Me.txtFood.Name = "txtFood"
        Me.txtFood.Size = New System.Drawing.Size(124, 26)
        Me.txtFood.TabIndex = 7
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radNonManagement)
        Me.GroupBox1.Controls.Add(Me.radManagement)
        Me.GroupBox1.Location = New System.Drawing.Point(126, 288)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 133)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Employee type:"
        '
        'radManagement
        '
        Me.radManagement.AutoSize = True
        Me.radManagement.Location = New System.Drawing.Point(35, 39)
        Me.radManagement.Name = "radManagement"
        Me.radManagement.Size = New System.Drawing.Size(128, 24)
        Me.radManagement.TabIndex = 0
        Me.radManagement.TabStop = True
        Me.radManagement.Text = "Management"
        Me.radManagement.UseVisualStyleBackColor = True
        '
        'radNonManagement
        '
        Me.radNonManagement.AutoSize = True
        Me.radNonManagement.Location = New System.Drawing.Point(35, 89)
        Me.radNonManagement.Name = "radNonManagement"
        Me.radNonManagement.Size = New System.Drawing.Size(162, 24)
        Me.radNonManagement.TabIndex = 1
        Me.radNonManagement.TabStop = True
        Me.radNonManagement.Text = "Non-Management"
        Me.radNonManagement.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblEmployeeDue)
        Me.GroupBox2.Controls.Add(Me.lblCompanyReimbursed)
        Me.GroupBox2.Controls.Add(Me.lblTotal)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Location = New System.Drawing.Point(497, 46)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(283, 174)
        Me.GroupBox2.TabIndex = 9
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Costs:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(38, 36)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(78, 20)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Total Trip:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(38, 85)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(99, 20)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Reimbursed:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(38, 129)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(135, 20)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Due by employee:"
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Location = New System.Drawing.Point(208, 36)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(57, 20)
        Me.lblTotal.TabIndex = 3
        Me.lblTotal.Text = "Label8"
        '
        'lblCompanyReimbursed
        '
        Me.lblCompanyReimbursed.AutoSize = True
        Me.lblCompanyReimbursed.Location = New System.Drawing.Point(208, 85)
        Me.lblCompanyReimbursed.Name = "lblCompanyReimbursed"
        Me.lblCompanyReimbursed.Size = New System.Drawing.Size(57, 20)
        Me.lblCompanyReimbursed.TabIndex = 4
        Me.lblCompanyReimbursed.Text = "Label8"
        '
        'lblEmployeeDue
        '
        Me.lblEmployeeDue.AutoSize = True
        Me.lblEmployeeDue.Location = New System.Drawing.Point(208, 129)
        Me.lblEmployeeDue.Name = "lblEmployeeDue"
        Me.lblEmployeeDue.Size = New System.Drawing.Size(57, 20)
        Me.lblEmployeeDue.TabIndex = 5
        Me.lblEmployeeDue.Text = "Label8"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(427, 350)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(118, 51)
        Me.btnCalculate.TabIndex = 10
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtFood)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtLodging)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtAirfare)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtTripLength)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtTripLength As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtAirfare As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtLodging As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtFood As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents radNonManagement As RadioButton
    Friend WithEvents radManagement As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblEmployeeDue As Label
    Friend WithEvents lblCompanyReimbursed As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents btnCalculate As Button
End Class
