﻿Public Class Form1
    Const dblManAirfare As Double = 500
    Const dblAirfare As Double = 400
    Const dblManPerDiemLodging As Double = 125
    Const dblManPerDiemFood As Double = 75
    Const dblPerDiemLodging As Double = 100
    Const dblPerDiemFood As Double = 50



    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim intDaysOfTrip As Integer = 0
        Dim dblAirfarePrice As Double = 0
        Dim dblLodgingPrice As Double = 0
        Dim dblFoodPrice As Double = 0
        Dim blnEmployeeType As Boolean = True
        Dim dblEmployeeDue As Double = 0
        Dim dblCompanyReimbursed As Double = 0
        Dim dblTotal As Double = 0
        Dim blnValidated As Boolean = True

        Call Validate_Inputs(intDaysOfTrip, dblAirfarePrice, dblLodgingPrice, dblFoodPrice, blnEmployeeType, dblEmployeeDue, dblCompanyReimbursed, dblTotal, blnValidated)



    End Sub


    Private Sub Validate_Inputs(ByRef intDaysOfTrip As Integer, ByRef dblAirfarePrice As Double, ByRef dblLodgingPrice As Double, ByRef dblFoodPrice As Double, ByRef blnEmployeeType As Boolean, ByRef dblEmployeeDue As Double, ByRef dblCompanyReimbursed As Double, ByRef dblTotal As Double, ByRef blnValidated As Boolean)


        Call Valid_DaysOfTrip(intDaysOfTrip, blnValidated)
        Call Valid_Airfare(dblAirfarePrice, blnValidated)
        Call Valid_Lodging(dblLodgingPrice, blnValidated)
        Call Valid_Food(dblFoodPrice, blnValidated)
        Call Valid_Employee(blnEmployeeType)

        If blnValidated = True Then
            Call Calculate_Price(intDaysOfTrip, dblAirfarePrice, dblLodgingPrice, dblFoodPrice, blnEmployeeType, dblEmployeeDue, dblCompanyReimbursed, dblTotal)
        End If

    End Sub

    Private Sub Valid_Employee(ByRef blnEmployeeType As Boolean)
        If radManagement.Checked Then
            blnEmployeeType = True
        Else
            If radNonManagement.Checked Then
                blnEmployeeType = False
            End If
        End If

    End Sub

    Private Sub Valid_Food(ByRef dblFoodPrice As Double, ByRef blnValidated As Boolean)
        If Double.TryParse(txtFood.Text, dblFoodPrice) Then
            blnValidated = True
        Else
            MessageBox.Show("Food costs must be included")
            blnValidated = False
        End If
    End Sub
    Private Sub Valid_Lodging(ByRef dblLodgingPrice As Double, ByRef blnValidated As Boolean)
        If Double.TryParse(txtLodging.Text, dblLodgingPrice) Then
            blnValidated = True
        Else
            MessageBox.Show("Lodging cost must be included")
            blnValidated = False
        End If
    End Sub


    Private Sub Valid_Airfare(ByRef dblAirFarePrice As Double, ByRef blnValidated As Boolean)
        If Double.TryParse(txtAirfare.Text, dblAirFarePrice) Then
            blnValidated = True
        Else
            MessageBox.Show("Airfare cost must be included")
            blnValidated = False
        End If
    End Sub

    Private Sub Valid_DaysOfTrip(ByRef intDaysOfTrip As Integer, ByRef blnvalidated As Boolean)
        If Integer.TryParse(txtTripLength.Text, intDaysOfTrip) Then
            intDaysOfTrip = txtTripLength.Text
            blnvalidated = True
        Else
            MessageBox.Show("Trip length must be an integer")
            blnvalidated = False
        End If
    End Sub


    Private Sub Calculate_Price(ByVal intDaysOfTrip As Integer, ByVal dblAirfarePrice As Double, ByVal dblLodgingPrice As Double, ByVal dblFoodPrice As Double, ByVal blnEmployeeType As Boolean, ByVal dblEmployeeDue As Double, ByVal dblCompanyReimbursed As Double, ByVal dblTotal As Double)
        ' Sloppy I know, no need to write this code out twice, needs to be re-done and save 100 lines of code.
        If blnEmployeeType = True Then
            Call Management_Calculations(dblTotal, intDaysOfTrip, dblAirfarePrice, dblLodgingPrice, dblFoodPrice, dblCompanyReimbursed, dblEmployeeDue)
        Else
            Call NonManagement_Calculations(dblTotal, intDaysOfTrip, dblAirfarePrice, dblLodgingPrice, dblFoodPrice, dblCompanyReimbursed, dblEmployeeDue)
        End If

    End Sub
    Private Sub Management_Calculations(ByVal dblTotal As Double, ByVal intDaysOfTrip As Integer, ByVal dblAirfarePrice As Double, ByVal dblLodgingPrice As Double, ByVal dblFoodPrice As Double, ByVal dblCompanyReimbursed As Double, ByVal dblEmployeeDue As Double)
        ' Initializing these two to divide expenses over the days stayed to compare to per diem
        ' Declared here as they will not be used elsewhere
        Dim dblLodgingDaily As Double
        Dim dblFoodDaily As Double

        'Airfare calculations
        dblTotal = dblTotal + dblAirfarePrice

        If dblAirfarePrice > dblManAirfare Then
            dblEmployeeDue = dblEmployeeDue + (dblAirfarePrice - dblManAirfare)
            dblCompanyReimbursed = dblCompanyReimbursed + dblManAirfare
        Else
            dblCompanyReimbursed = dblAirfarePrice
        End If

        'Food Calculations
        dblTotal = dblTotal + dblFoodPrice
        dblFoodDaily = dblFoodPrice / intDaysOfTrip
        If dblFoodDaily > dblManPerDiemFood Then
            dblEmployeeDue = dblEmployeeDue + ((dblFoodDaily - dblManPerDiemFood) * intDaysOfTrip)
            dblCompanyReimbursed = dblCompanyReimbursed + (dblManPerDiemFood * intDaysOfTrip)
        Else
            dblCompanyReimbursed = dblFoodPrice
        End If

        'Lodging Calculations
        dblTotal = dblTotal + dblLodgingPrice
        dblLodgingDaily = dblLodgingPrice / intDaysOfTrip
        If dblLodgingDaily > dblManPerDiemLodging Then
            dblEmployeeDue = dblEmployeeDue + ((dblLodgingDaily - dblManPerDiemLodging) * intDaysOfTrip)
            dblCompanyReimbursed = dblCompanyReimbursed + (dblManPerDiemLodging * intDaysOfTrip)
        Else
            dblCompanyReimbursed = dblLodgingPrice
        End If


        lblTotal.Text = dblTotal
        lblEmployeeDue.Text = dblEmployeeDue
        lblCompanyReimbursed.Text = dblCompanyReimbursed
    End Sub


    Private Sub NonManagement_Calculations(ByVal dblTotal As Double, ByVal intDaysOfTrip As Integer, ByVal dblAirfarePrice As Double, ByVal dblLodgingPrice As Double, ByVal dblFoodPrice As Double, ByVal dblCompanyReimbursed As Double, ByVal dblEmployeeDue As Double)
        ' Initializing these two to divide expenses over the days stayed to compare to per diem
        ' Declared here as they will not be used elsewhere
        Dim dblLodgingDaily As Double
        Dim dblFoodDaily As Double

        'Airfare calculations
        dblTotal = dblTotal + dblAirfarePrice

        If dblAirfarePrice > dblAirfare Then
            dblEmployeeDue = dblEmployeeDue + (dblAirfarePrice - dblAirfare)
            dblCompanyReimbursed = dblCompanyReimbursed + dblAirfare
        Else
            dblCompanyReimbursed = dblAirfarePrice
        End If

        'Food Calculations
        dblTotal = dblTotal + dblFoodPrice
        dblFoodDaily = dblFoodPrice / intDaysOfTrip
        If dblFoodDaily > dblPerDiemFood Then
            dblEmployeeDue = dblEmployeeDue + ((dblFoodDaily - dblPerDiemFood) * intDaysOfTrip)
            dblCompanyReimbursed = dblCompanyReimbursed + (dblPerDiemFood * intDaysOfTrip)
        Else
            dblCompanyReimbursed = dblFoodPrice
        End If

        'Lodging Calculations
        dblTotal = dblTotal + dblLodgingPrice
        dblLodgingDaily = dblLodgingPrice / intDaysOfTrip
        If dblLodgingDaily > dblPerDiemFood Then
            dblEmployeeDue = dblEmployeeDue + ((dblLodgingDaily - dblPerDiemFood) * intDaysOfTrip)
            dblCompanyReimbursed = dblCompanyReimbursed + (dblPerDiemFood * intDaysOfTrip)
        Else
            dblCompanyReimbursed = dblLodgingPrice
        End If


        lblTotal.Text = dblTotal
        lblEmployeeDue.Text = dblEmployeeDue
        lblCompanyReimbursed.Text = dblCompanyReimbursed
    End Sub

End Class



